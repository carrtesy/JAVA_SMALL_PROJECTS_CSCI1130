
package chart;

/**
 * Interface Function is given
 * @author pffung
 */
public interface Function {
    double valueAt(double x);
}
